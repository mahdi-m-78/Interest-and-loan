package com.utotech.bankPercentage.fragments

import android.os.Bundle
import android.text.Editable
import android.text.SpannableString
import android.text.TextWatcher
import android.text.style.RelativeSizeSpan
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textview.MaterialTextView
import com.utotech.bankPercentage.R
import java.lang.NumberFormatException
import java.text.DecimalFormat
import java.text.Format
import java.text.NumberFormat
import java.util.*



import android.widget.Button
import android.widget.EditText

import android.widget.TextView
import android.widget.Toast






class InterestFragment : Fragment() {


    lateinit var edt_amount_layout: TextInputEditText
    lateinit var edt_Interest_rate_layout: TextInputEditText
    lateinit var edt_month_loan: MaterialTextView
    lateinit var edt_year_loan: MaterialTextView
    lateinit var edt_daily_loan: MaterialTextView
    lateinit var btn_reset: Button
    lateinit var btn_calcute: Button
    lateinit var amnt: EditText
    lateinit var edt_Installment_layout : TextView
    lateinit var edt_day_layout:TextView
    lateinit var edt_month_layout_mlt :TextView
    lateinit var edt_year_layout :TextView




    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        val view = inflater.inflate(R.layout.fragment_interest, container, false)


        amnt = view.findViewById<TextInputEditText>(R.id.edt_amount_layout)


        amnt.addTextChangedListener(onTextChangedListener())



        val Computing = view.findViewById<Button>(R.id.btn_submit)

        val amount_check = view.findViewById<TextInputEditText>(R.id.edt_amount_layout)
        val month_check = view.findViewById<TextInputEditText>(R.id.edt_month_layout)
        val sod_check = view.findViewById<TextInputEditText>(R.id.edt_Interest_rate_layout)



        Computing.setOnClickListener(View.OnClickListener {

            if(amount_check.text?.isEmpty() == true  ||  month_check.text?.isEmpty() == true  ||  sod_check.text?.isEmpty() == true ){
                Toast.makeText(context, "لطفا تمامی فیلد ها را پر کنید ", Toast.LENGTH_SHORT).show()

            }else{



                var amount =  amnt.text.toString()

                var amount_mlt = amount.replace(",", "").toLong()


                var month_mlt =view.findViewById<TextInputEditText>(R.id.edt_month_layout).text.toString().toLong() * 30

                var sod_mlt  =  view.findViewById<TextInputEditText>(R.id.edt_Interest_rate_layout).text.toString().toLong()


                var month_result = view.findViewById<TextInputEditText>(R.id.edt_month_layout).text.toString().toLong()











                val formatter = DecimalFormat("###,###")




                // "کل سود  "
                val result_mon: Double = ((amount_mlt * month_mlt * sod_mlt) / 36500.0)

                val result_end_mon: String = formatter.format(result_mon)

                view.findViewById<TextView>(R.id.edt_Installment_layout).text =  "کل مبلغ سود (ریال) : "  + result_end_mon






                //"سود روزانه ملت "
                val result_day: Double = result_mon / month_mlt

                val result_end_day: String = formatter.format(result_day)

                view.findViewById<TextView>(R.id.edt_day_layout).text = "سود روزانه   (ریال) : " + result_end_day






                // "سود ماهانه ملت "
                val result_month = result_mon / month_result

                val result_end_month : String = formatter.format(result_month)

                view.findViewById<TextView>(R.id.edt_month_layout_mlt).text = "سود ماهانه   (ریال) : " + result_end_month





                //"سود سالانه ملت "
                val result_year: Double = result_mon * 12

                val result_end_year: String = formatter.format(result_year)

                view.findViewById<TextView>(R.id.edt_year_layout).text = "سود سالانه   (ریال) : " + result_end_year


            }



            view.findViewById<Button>(R.id.btn_reset).setOnClickListener(View.OnClickListener {
                Toast.makeText(context, "مقادیر جدید را وارد کنید ", Toast.LENGTH_LONG).show()




                view.findViewById<TextInputEditText>(R.id.edt_amount_layout).text?.clear()

                view.findViewById<TextInputEditText>(R.id.edt_Interest_rate_layout).text?.clear()

                view.findViewById<TextInputEditText>(R.id.edt_month_layout).text?.clear()





                view.findViewById<TextView>(R.id.edt_day_layout).text = resources.getString(R.string.daily_loan)

                view.findViewById<TextView>(R.id.edt_Installment_layout).text = resources.getString(R.string.month_loan)

                view.findViewById<TextView>(R.id.edt_year_layout).text = resources.getString(R.string.year_loan)

                view.findViewById<TextView>(R.id.edt_month_layout_mlt).text = resources.getString(R.string.edt_month_22)


            })

        })

        return view

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


    }

    private fun onTextChangedListener(): TextWatcher {

        return object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(s: Editable?) {
                amnt.removeTextChangedListener(this)


                try {

                    var originalString = s.toString()

                    if (originalString.contains(",")) {

                        originalString = originalString.replace(",", "")

                    }

                    val longVal = originalString.toLong()

                    val formatter = NumberFormat.getInstance(Locale.US) as DecimalFormat
                    formatter.applyPattern("#,###,###,###")

                    val formattedString = formatter.format(longVal)

                    amnt.setText(formattedString)
                    amnt.setSelection(amnt.text.length)

                } catch (e: NumberFormatException) {

                    e.printStackTrace()

                }

                amnt.addTextChangedListener(this)

            }

        }

    }




}













