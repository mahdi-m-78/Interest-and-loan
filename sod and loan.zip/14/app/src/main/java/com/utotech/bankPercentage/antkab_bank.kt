package com.utotech.bankPercentage

import android.app.Activity
import android.content.Intent

import android.os.Bundle

import android.widget.ImageButton

class antkab_bank : Activity() {

    lateinit var img_btn_meli: ImageButton
      lateinit var img_btn_mlt: ImageButton

    override
    fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_antkab_bank)





        //"انتخاب بانک ملت"
        img_btn_mlt= findViewById(R.id.img_btn_mlt)

        img_btn_mlt.setOnClickListener {


            //"انیمیشن"
            img_btn_mlt.animate().apply {

                duration=1000
                rotationXBy(36000f)

            }.start()


            val intent = Intent(this, MainActivity::class.java)

            startActivity(intent)
        }


        //"انتخاب بانک ملی"
        img_btn_meli= findViewById(R.id.img_btn_meli)

        img_btn_meli.setOnClickListener {


            //"انیمیشن"
            img_btn_meli.animate().apply {

                duration=1000
                rotationXBy(36000f)


            }.start()


            val intent = Intent(this, MainActivity_2::class.java)

            startActivity(intent)
        }

    }
}