package com.utotech.bankPercentage.adapter_2

import android.util.Log
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.utotech.bankPercentage.fragments.InterestFragment
import com.utotech.bankPercentage.fragments.LoanFragment
import com.utotech.bankPercentage.fragments_2.loan_2
import com.utotech.bankPercentage.fragments_2.sod_2

class pager_2 (fragmentActivity: FragmentActivity) :
    FragmentStateAdapter(fragmentActivity) {
    var fragments_2: MutableList<Fragment> = mutableListOf()
    init {
        fragments_2.add(loan_2())
        fragments_2.add(sod_2())

    }



    override fun getItemCount(): Int {
        return 2 ;
    }

    override fun createFragment(position: Int): Fragment {

        return fragments_2.get(position)
    }

}