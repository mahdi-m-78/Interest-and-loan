package com.utotech.bankPercentage.fragments_2


import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textview.MaterialTextView
import com.utotech.bankPercentage.R
import java.lang.NumberFormatException
import java.text.DecimalFormat
import java.text.NumberFormat
import java.util.*
import kotlin.math.pow


class loan_2 : Fragment() {


    lateinit var edt_amount_layout_2: TextInputEditText
    lateinit var edt_Interest_rate_layout_2: TextInputEditText
    lateinit var edt_refund_layout_2: TextInputEditText
    lateinit var edt_Installment_layout_2: MaterialTextView
    lateinit var edt_loan_layout_2: MaterialTextView
    lateinit var btn_reset_2: Button

    lateinit var amt_loan: EditText

    lateinit var btn_calcute_2: Button
    lateinit var radioGroup_2: RadioGroup
    lateinit var edt_sum_layout_2 : MaterialTextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {

        val view: View = inflater.inflate(R.layout.fragment_loan_meli, container, false);

        amt_loan = view.findViewById<TextInputEditText>(R.id.edt_amount_layout_2)

        amt_loan.addTextChangedListener(onTextChangedListener())





        edt_amount_layout_2 = view.findViewById(R.id.edt_amount_layout_2)

        edt_Interest_rate_layout_2 = view.findViewById(R.id.edt_Interest_rate_layout_2)

        edt_refund_layout_2 = view.findViewById(R.id.edt_refund_layout_2)

        edt_Installment_layout_2 = view.findViewById(R.id.edt_Installment_layout_2)

        edt_loan_layout_2 = view.findViewById(R.id.edt_loan_layout_2)

        btn_reset_2 = view.findViewById(R.id.btn_reset_2)

        btn_calcute_2 = view.findViewById(R.id.btn_submit_2)

        radioGroup_2 = view.findViewById(R.id.radioGroup_2)

        edt_sum_layout_2  = view.findViewById(R.id.edt_sum_layout_2)





        btn_calcute_2.setOnClickListener(View.OnClickListener {


            var amount_loan = edt_amount_layout_2.text.toString()
            var rate_loan = edt_Interest_rate_layout_2.text.toString()
            var month_loan = edt_refund_layout_2.text.toString()


            if (amount_loan.equals ("")  ||  rate_loan.equals ("")   ||  month_loan.equals ("") ) {


                Toast.makeText(context, "لطفا تمامی فیلد ها را پر کنید", Toast.LENGTH_LONG).show()


            }else{





                var amount_mlt =  amt_loan.text.toString()

                var amount_loan = amount_mlt.replace(",", "").toLong()


                var rate_loan = edt_Interest_rate_layout_2.text.toString().toDouble()

                var month_loan = edt_refund_layout_2.text.toString().toDouble()

                val checkedRadioButtonId = radioGroup_2.checkedRadioButtonId





                // "فرمت خروجی"
                val formatter = DecimalFormat("###,###")




                if (checkedRadioButtonId == R.id.radio_button_1_2) {


                    //"فرمول جدید "

                    //"قسط وام ملت "
                    var sort= (amount_loan * (rate_loan / 1200))

                    var makrj= (1 + (rate_loan / 1200)).pow(month_loan)

                    var result = (sort * makrj) / (makrj - 1)



                    val yourFormattedString: String = formatter.format(result)
                    edt_Installment_layout_2.text = "قسط ماهانه : " + yourFormattedString + " ریال  "




                    //"سود وام ملت "
                    var sod_new =  (  result * month_loan ) - amount_loan

                    var sodFormated: String = formatter.format(sod_new)
                    edt_loan_layout_2.text = "کل سود وام : " + sodFormated + " ریال  "



                    //"جمع سود وام و اصل وام جدید "
                    var sum = amount_loan + sod_new

                    var sumformat:String = formatter.format(sum)
                    edt_sum_layout_2.text = "جمع اصل وام و سود وام : " + sumformat + " ریال  "





                } else {



                    //"فرمول قدیم "
                    var sod =  ( amount_loan * rate_loan * (month_loan + 1) ) / 2400

                    var Installment = (sod + amount_loan) / month_loan







                    //"سود وام ملت "
                    var loanFormated: String = formatter.format(sod)
                    edt_loan_layout_2.text = "کل سود وام : " + loanFormated +" ریال  "






                    //"قسط وام ملت "
                    var FormatedInstallment: String = formatter.format(Installment)
                    edt_Installment_layout_2.text = " قسط ماهانه : " + FormatedInstallment +" ریال  "





                    //"جمع سود وام و اصل وام قدیم "
                    var sum_old = amount_loan + sod

                    var sumformat:String = formatter.format(sum_old)
                    edt_sum_layout_2.text = "جمع اصل وام و سود وام : " + sumformat+ " ریال  "




                }

            }

        })



        btn_reset_2.setOnClickListener(View.OnClickListener {


            Toast.makeText(context, "لطفا مقادیر جدید را وارد کنید ", Toast.LENGTH_LONG).show()



            edt_amount_layout_2.text?.clear()
            edt_Interest_rate_layout_2.text?.clear()
            edt_refund_layout_2.text?.clear()


            edt_Installment_layout_2.text = resources.getString(R.string.enter_Installment_value)
            edt_loan_layout_2.text = resources.getString(R.string.enter_loan_value)
            edt_sum_layout_2.text = resources.getString(R.string.edt_sum_layout_2)



        })
        return view
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }

    private fun onTextChangedListener(): TextWatcher {

        return object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(s: Editable?) {
                amt_loan.removeTextChangedListener(this)


                try {

                    var originalString = s.toString()

                    if (originalString.contains(",")) {

                        originalString = originalString.replace(",", "")

                    }

                    val longVal = originalString.toLong()

                    val formatter = NumberFormat.getInstance(Locale.US) as DecimalFormat
                    formatter.applyPattern("#,###,###,###")

                    val formattedString = formatter.format(longVal)

                    amt_loan.setText(formattedString)
                    amt_loan.setSelection(amt_loan.text.length)

                } catch (e: NumberFormatException) {

                    e.printStackTrace()

                }

                amt_loan.addTextChangedListener(this)

            }

        }

    }


}