package com.utotech.bankPercentage

import android.content.Context
import android.content.DialogInterface
import android.os.Bundle
import android.os.PersistableBundle
import android.widget.Button
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.utotech.bankPercentage.adapter.MainPagerAdapter
import com.utotech.bankPercentage.adapter_2.pager_2


class MainActivity_2 : AppCompatActivity() {


    lateinit var bottom_nav_2: BottomNavigationView
    lateinit var pager_2: ViewPager2
    lateinit var adapter_2: pager_2


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_2)







        initial()
        bottom_nav_2.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)
        pager_2.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {

                if (position == 1) {
                    bottom_nav_2.menu.getItem(0).setChecked(true)

                } else {
                    bottom_nav_2.menu.getItem(1).setChecked(true)
                }
                super.onPageSelected(position)
            }
        })



    }



    fun initial() {
        pager_2 = findViewById(R.id.pager_2)
        bottom_nav_2 = findViewById(R.id.bottom_nav_2)
        adapter_2 = pager_2(this)
        pager_2.adapter = adapter_2
    }

    private val mOnNavigationItemSelectedListener =
        BottomNavigationView.OnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.Interest_2 -> {
                    pager_2.currentItem = 0
                    return@OnNavigationItemSelectedListener true
                }
                R.id.loans_2 -> {
                    pager_2.currentItem = 1
                    return@OnNavigationItemSelectedListener true
                }
            }
            false
        }


}










