package com.utotech.bankPercentage.fragments_2

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import android.widget.Button
import android.widget.EditText

import android.widget.TextView
import android.widget.Toast
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment


import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textview.MaterialTextView
import com.utotech.bankPercentage.NumberTextWatcher
import com.utotech.bankPercentage.R
import kotlinx.android.synthetic.main.fragment_sod_meli.*
import java.lang.NumberFormatException
import java.text.DecimalFormat
import java.text.NumberFormat
import java.util.*



class sod_2  : Fragment() {


    lateinit var edt_amount_layout_22: TextInputEditText
    lateinit var edt_Interest_rate_layout_22: TextInputEditText
    lateinit var edt_month_loan_22: MaterialTextView
    lateinit var edt_year_loan_22: MaterialTextView
    lateinit var edt_daily_loan_22: MaterialTextView
    lateinit var btn_reset_22: Button
    lateinit var btn_calcute_22: Button
    lateinit var edt_month_layout_22: TextInputEditText
    lateinit var amt: EditText
    lateinit var edt_Installment_layout_22: TextView
    lateinit var edt_day_layout_22: TextView
    lateinit var edt_year_layout_22: TextView
    lateinit var btn_submit_22 : Button
    lateinit var textView3 : TextView




    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {

        val view = inflater.inflate(R.layout.fragment_sod_meli, container, false)

        amt = view.findViewById<TextInputEditText>(R.id.edt_amount_layout_22)

        amt.addTextChangedListener(onTextChangedListener())




        val mSubmit = view.findViewById<Button>(R.id.btn_submit_22)


        val amountEdit = view.findViewById<TextInputEditText>(R.id.edt_amount_layout_22)

        val monthEdit = view.findViewById<TextInputEditText>(R.id.edt_month_layout_22)

        val rateEdit = view.findViewById<TextInputEditText>(R.id.edt_Interest_rate_layout_22)



        mSubmit.setOnClickListener(View.OnClickListener {

            if(amountEdit.text?.isEmpty() == true || monthEdit.text?.isEmpty() == true || rateEdit.text?.isEmpty() == true){
                Toast.makeText(context, "لطفا فیلد ها را پر کنید ", Toast.LENGTH_SHORT).show()

            }else{






                var amount_sod =  amt.text.toString()

                var amount = amount_sod.replace(",", "").toLong()

                var month  =  view.findViewById<TextInputEditText>(R.id.edt_month_layout_22).text.toString().toLong() * 30

                var sod    =  view.findViewById<TextInputEditText>(R.id.edt_Interest_rate_layout_22).text.toString().toLong()



                var month_result = view.findViewById<TextInputEditText>(R.id.edt_month_layout_22).text.toString().toLong()




                //"فرمت اعداد خروجی"
                val formatter = DecimalFormat("###,###")






                // " کل مبلغ سود  ملی  "
                val result_all_month :Double = ((amount * month * sod) / 36500.0)


                val form_res_all_month: String = formatter.format(result_all_month)

                view.findViewById<TextView>(R.id.edt_Installment_layout_22).text ="کل مبلغ سود (ریال) : " +  form_res_all_month







                //"سود روزانه "
                val result_day: Double = result_all_month / month

                val result_end_day : String = formatter.format(result_day)

                view.findViewById<TextView>(R.id.edt_day_layout_22).text = "سود روزانه   (ریال) : " + result_end_day




                //"سود ماهانه "
                val result_month = result_all_month / month_result

                val result_end_month : String = formatter.format(result_month)

                view.findViewById<TextView>(R.id.edt_month_22).text = "سود ماهانه   (ریال) : " + result_end_month






                //"سود سالانه "
                val result_year: Double = result_month * 12

                val result_end_year : String = formatter.format(result_year)

                view.findViewById<TextView>(R.id.edt_year_layout_22).text = "سود سالانه   (ریال) : " + result_end_year

            }









            //"ریست مفادیر "
            view.findViewById<Button>(R.id.btn_reset_22).setOnClickListener(View.OnClickListener {

                Toast.makeText(context, "مقادیر جدید را وارد کنید ", Toast.LENGTH_LONG).show()


                //"ورودی ها را پاک میکند"
                view.findViewById<TextInputEditText>(R.id.edt_amount_layout_22).text?.clear()
                view.findViewById<TextInputEditText>(R.id.edt_Interest_rate_layout_22).text?.clear()
                view.findViewById<TextInputEditText>(R.id.edt_month_layout_22).text?.clear()



                //"جواب را پاک می کند"
                view.findViewById<TextView>(R.id.edt_day_layout_22).text = resources.getString(R.string.daily_loan)
                view.findViewById<TextView>(R.id.edt_Installment_layout_22).text = resources.getString(R.string.month_loan)
                view.findViewById<TextView>(R.id.edt_year_layout_22).text = resources.getString(R.string.year_loan)
                view.findViewById<TextView>(R.id.edt_month_22).text = resources.getString(R.string.edt_month_22)


            })

        })
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)




    }

    private fun onTextChangedListener(): TextWatcher {

        return object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(s: Editable?) {
                amt.removeTextChangedListener(this)


                try {

                    var originalString = s.toString()

                    if (originalString.contains(",")) {

                        originalString = originalString.replace(",", "")

                    }

                    val longVal = originalString.toLong()

                    val formatter = NumberFormat.getInstance(Locale.US) as DecimalFormat
                    formatter.applyPattern("#,###,###,###")

                    val formattedString = formatter.format(longVal)

                    amt.setText(formattedString)
                    amt.setSelection(amt.text.length)

                } catch (e: NumberFormatException) {

                    e.printStackTrace()

                }

                amt.addTextChangedListener(this)

            }

        }

    }



}









