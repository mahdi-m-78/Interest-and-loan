package com.utotech.bankPercentage.fragments

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textview.MaterialTextView
import com.utotech.bankPercentage.R
import kotlinx.android.synthetic.main.fragment_loan.*
import java.lang.NumberFormatException
import java.text.DecimalFormat
import java.text.NumberFormat
import java.util.*
import kotlin.math.pow


class LoanFragment : Fragment() {
    lateinit var edt_amount_layout: TextInputEditText
    lateinit var edt_Interest_rate_layout: TextInputEditText
    lateinit var edt_refund_layout: TextInputEditText
    lateinit var edt_Installment_layout: MaterialTextView
    lateinit var edt_loan_layout: MaterialTextView
    lateinit var btn_reset: Button

    lateinit var amt_loan_mlt: EditText

    lateinit var btn_calcute: Button
    lateinit var radioGroup: RadioGroup
    lateinit var edt_sum_layout : MaterialTextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        val view: View = inflater.inflate(R.layout.fragment_loan, container, false);


        amt_loan_mlt = view.findViewById<TextInputEditText>(R.id.edt_amount_layout)

        amt_loan_mlt.addTextChangedListener(onTextChangedListener())




        edt_amount_layout = view.findViewById(R.id.edt_amount_layout )
        edt_Interest_rate_layout = view.findViewById(R.id.edt_Interest_rate_layout)

        edt_refund_layout = view.findViewById(R.id.edt_refund_layout)

        edt_Installment_layout = view.findViewById(R.id.edt_Installment_layout)

        edt_loan_layout = view.findViewById(R.id.edt_loan_layout)

        btn_reset = view.findViewById(R.id.btn_reset)

        btn_calcute = view.findViewById(R.id.btn_submit)

        radioGroup = view.findViewById(R.id.radioGroup)

        edt_sum_layout = view.findViewById(R.id.edt_sum_layout)






        btn_calcute.setOnClickListener(View.OnClickListener {


            var amount_loan = edt_amount_layout.text.toString()
            var rate_loan = edt_Interest_rate_layout.text.toString()
            var month_loan = edt_refund_layout.text.toString()


            if (amount_loan.equals ("")  ||  rate_loan.equals ("")   ||  month_loan.equals ("")  ) {


                Toast.makeText(context, "لطفا تمامی فیلد ها را پر کنید", Toast.LENGTH_LONG).show()


            }else{




                var amount_mlt =  amt_loan_mlt.text.toString()

                var amount_loan = amount_mlt.replace(",", "").toLong()






                var rate_loan = edt_Interest_rate_layout.text.toString().toDouble()

                var month_loan = edt_refund_layout.text.toString().toDouble()

                val checkedRadioButtonId = radioGroup.checkedRadioButtonId






                val formatter = DecimalFormat("###,###")





                if (checkedRadioButtonId == R.id.radio_button_1) {


                    //"فرمول جدید "

                    //"قسط وام ملت "
                    var sort= (amount_loan * (rate_loan / 1200))

                    var makrj= (1 + (rate_loan / 1200)).pow(month_loan)


                    var result = (sort * makrj) / (makrj - 1)


                    val yourFormattedString: String = formatter.format(result.toDouble())
                    edt_Installment_layout.text = "مبلغ هر قسط : " + yourFormattedString +" ریال  "



                    //"سود وام ملت "

                    var sod_new =  (  result * month_loan) - amount_loan

                    var sodFormated: String = formatter.format(sod_new)
                    edt_loan_layout.text = "مقدار سود وام : " + sodFormated + " ریال  "







                    //"جمع سود وام و اصل وام جدید ملت "

                    var sum_new_mlt = amount_loan + sod_new

                    var sumformat :String = formatter.format(sum_new_mlt)
                    edt_sum_layout.text = "جمع اصل وام و سود وام : " + sumformat + " ریال  "







                } else {



                    //"فرمول قدیم "
                    var sod_mlt =  ( amount_loan * rate_loan * (month_loan + 1) ) / 2400

                    var Installment = (sod_mlt + amount_loan) / month_loan




                    //"سود وام ملت "
                    var loanFormated: String = formatter.format(sod_mlt)
                    edt_loan_layout.text = "مقدار سود وام " + loanFormated + " ریال  "




                    //"قسط وام ملت "
                    var FormatedInstallment: String = formatter.format(Installment)
                    edt_Installment_layout.text = "مبلغ هر قسط : " + FormatedInstallment +" ریال  "




                    //"جمع سود وام و اصل وام قدیم ملت "
                    var sum_old_mlt = amount_loan + sod_mlt

                    var sumformat:String = formatter.format(sum_old_mlt)
                    edt_sum_layout.text = "جمع اصل وام و سود وام : " + sumformat+ " ریال  "






                }

            }

        })



        btn_reset.setOnClickListener(View.OnClickListener {


            edt_amount_layout.text?.clear()
            edt_Interest_rate_layout.text?.clear()
            edt_refund_layout.text?.clear()


            edt_Installment_layout.text = resources.getString(R.string.enter_Installment_value)
            edt_loan_layout.text = resources.getString(R.string.enter_loan_value)
            edt_sum_layout.text = resources.getString(R.string.edt_sum_layout)


        })
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }
    private fun onTextChangedListener(): TextWatcher {

        return object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(s: Editable?) {
                amt_loan_mlt.removeTextChangedListener(this)


                try {

                    var originalString = s.toString()

                    if (originalString.contains(",")) {

                        originalString = originalString.replace(",", "")

                    }

                    val longVal = originalString.toLong()

                    val formatter = NumberFormat.getInstance(Locale.US) as DecimalFormat
                    formatter.applyPattern("#,###,###,###")

                    val formattedString = formatter.format(longVal)

                    amt_loan_mlt.setText(formattedString)
                    amt_loan_mlt.setSelection(amt_loan_mlt.text.length)

                } catch (e: NumberFormatException) {

                    e.printStackTrace()

                }

                amt_loan_mlt.addTextChangedListener(this)

            }

        }

    }









}












