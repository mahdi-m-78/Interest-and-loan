package com.utotech.bankPercentage

import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import org.w3c.dom.Text
import java.lang.NumberFormatException
import java.text.DecimalFormat
import java.text.NumberFormat
import java.util.*

class NumberTextWatcher(private val amt: EditText   ) {



    }