package com.utotech.bankPercentage.adapter

import android.util.Log
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.utotech.bankPercentage.fragments.InterestFragment
import com.utotech.bankPercentage.fragments.LoanFragment

class MainPagerAdapter(fragmentActivity: FragmentActivity) :
    FragmentStateAdapter(fragmentActivity) {
     var fragments: MutableList<Fragment> = mutableListOf()
    init {
        fragments.add(LoanFragment())
        fragments.add(InterestFragment())
    }




    override fun getItemCount(): Int {
        return 2;
    }

    override fun createFragment(position: Int): Fragment {

        return fragments.get(position)
    }

}