package com.utotech.bankPercentage

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.utotech.bankPercentage.adapter.MainPagerAdapter



class MainActivity : AppCompatActivity() {
    lateinit var pager: ViewPager2
    lateinit var adapter: MainPagerAdapter
    lateinit var bottom_nav: BottomNavigationView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)




        initial()
        bottom_nav.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                if (position == 1) {
                    bottom_nav.menu.getItem(0).setChecked(true)
                } else {
                    bottom_nav.menu.getItem(1).setChecked(true)
                }
                super.onPageSelected(position)
            }
        })
    }

    fun initial() {
        pager = findViewById(R.id.pager)
        bottom_nav = findViewById(R.id.bottom_nav)
        adapter = MainPagerAdapter(this)
        pager.adapter = adapter

    }

    private val mOnNavigationItemSelectedListener =
        BottomNavigationView.OnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.Interest -> {
                    pager.currentItem = 0
                    return@OnNavigationItemSelectedListener true
                }
                R.id.loans -> {
                    pager.currentItem = 1
                    return@OnNavigationItemSelectedListener true
                }
            }
            false
        }

}